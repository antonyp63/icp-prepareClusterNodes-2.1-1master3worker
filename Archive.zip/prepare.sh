#!/bin/bash

#COMMON ENV VARIABLES
BIN_DOWNLOAD_DIR="/tmp/icp-ee"
#INSTALL_DIR="/opt/ibm-cloud-private-2.1.0-beta"

#install sshpass
tar zxvf /tmp/icp/boot/sshpass-1.06.tar.gz -C /tmp/
cd /tmp/sshpass-1.06 && ./configure
cd /tmp/sshpass-1.06 && make
cd /tmp/sshpass-1.06 && make install



#download binaries
mkdir -p ${BIN_DOWNLOAD_DIR}

#step 2 - download installer (2.1beta)
wget -P ${BIN_DOWNLOAD_DIR} ${INSTALLER_BASEURL}/${INSTALLER_FILENAME}

#step 3 - load images into Docker
cd ${BIN_DOWNLOAD_DIR} && tar xf ${INSTALLER_FILENAME} -O | sudo docker load

#create working directory for installation
#step 4
mkdir -p ${INSTALL_DIR}

#step 5 & 6
cd ${INSTALL_DIR} && sudo docker run -v $(pwd):/data -e LICENSE=accept ${IMAGE_NAME} cp -r cluster /data

#step 7
#gen key can copy pub key across cluster nodes
ssh-keygen -b 4096 -t rsa -f ~/.ssh/master.id_rsa -N ""
cat ~/.ssh/master.id_rsa.pub | sudo tee -a /root/.ssh/authorized_keys

if [[ ! -z ${MASTER_1_IP+x} ]]; then
	echo "Copy SSH key to Master Node 1"
	echo ${MASTER_1_IP}
	ssh-keyscan ${MASTER_1_IP} | sudo tee -a /root/.ssh/known_hosts
	sshpass -p ${SSH_ROOT_PWD} scp ~/.ssh/master.id_rsa.pub root@${MASTER_1_IP}:~/.ssh/master.id_rsa.pub
	sleep 2
	sshpass -p ${SSH_ROOT_PWD} ssh -tt root@${MASTER_1_IP} 'cat ~/.ssh/master.id_rsa.pub | sudo tee -a /root/.ssh/authorized_keys ; echo "PermitRootLogin yes" | sudo tee -a /etc/ssh/sshd_config ; sysctl -w vm.max_map_count=262144'
	sleep 2
fi

if [[ ! -z ${WORKER_1_IP+x} ]]; then
	echo "Copy SSH key to Worker Node 1"
	echo ${WORKER_1_IP}
	ssh-keyscan ${WORKER_1_IP} | sudo tee -a /root/.ssh/known_hosts
	sshpass -p ${SSH_ROOT_PWD} scp ~/.ssh/master.id_rsa.pub root@${WORKER_1_IP}:~/.ssh/master.id_rsa.pub
	sleep 2
	sshpass -p ${SSH_ROOT_PWD} ssh -tt root@${WORKER_1_IP} 'cat ~/.ssh/master.id_rsa.pub | sudo tee -a /root/.ssh/authorized_keys ; echo "PermitRootLogin yes" | sudo tee -a /etc/ssh/sshd_config ; sysctl -w vm.max_map_count=262144'
	sleep 2
fi

if [[ ! -z ${WORKER_2_IP+x} ]]; then
	echo "Copy SSH key to Worker Node 2"
	echo ${WORKER_2_IP}
	ssh-keyscan ${WORKER_2_IP} | sudo tee -a /root/.ssh/known_hosts
	sshpass -p ${SSH_ROOT_PWD} scp ~/.ssh/master.id_rsa.pub root@${WORKER_2_IP}:~/.ssh/master.id_rsa.pub
	sleep 2
	sshpass -p ${SSH_ROOT_PWD} ssh -tt root@${WORKER_2_IP} 'cat ~/.ssh/master.id_rsa.pub | sudo tee -a /root/.ssh/authorized_keys ; echo "PermitRootLogin yes" | sudo tee -a /etc/ssh/sshd_config ; sysctl -w vm.max_map_count=262144'
	sleep 2
fi

if [[ ! -z ${WORKER_3_IP+x} ]]; then
	echo "Copy SSH key to Worker Node 3"
	echo ${WORKER_3_IP}
	ssh-keyscan ${WORKER_3_IP} | sudo tee -a /root/.ssh/known_hosts
	sshpass -p ${SSH_ROOT_PWD} scp ~/.ssh/master.id_rsa.pub root@${WORKER_3_IP}:~/.ssh/master.id_rsa.pub
	sleep 2
	sshpass -p ${SSH_ROOT_PWD} ssh -tt root@${WORKER_3_IP} 'cat ~/.ssh/master.id_rsa.pub | sudo tee -a /root/.ssh/authorized_keys ; echo "PermitRootLogin yes" | sudo tee -a /etc/ssh/sshd_config ; sysctl -w vm.max_map_count=262144'
	sleep 2
fi


#step 8 - modify hosts
tee ${INSTALL_DIR}/cluster/hosts <<-EOF
[master]
${MASTER_1_IP}


[worker]
${WORKER_1_IP}
${WORKER_2_IP}
${WORKER_3_IP}

[proxy]
${MASTER_1_IP}



EOF

#step 9 - Setting up SSH Key
cp ~/.ssh/master.id_rsa ${INSTALL_DIR}/cluster/ssh_key
chmod 400 ${INSTALL_DIR}/cluster/ssh_key

#step 10 & 11 - modify config.yaml
tee -a ${INSTALL_DIR}/cluster/config.yaml <<-EOF


#replace api server port to avoid conflict with Pure mgmt port
kube_apiserver_insecure_port: 10888
cluster_name: icpcluster

#IP over IP mode
calico_ipip_enabled: ${CALICO_IPIP_ENABLED}

EOF


# source the properties:
if [[ -e "/etc/db2vip.conf" ]]; then
	. /etc/db2vip.conf
	tee -a ${INSTALL_DIR}/cluster/config.yaml <<-EOF

		#HA settings
		vip_iface: eth0
		cluster_vip: ${VIP_CLUSTER}

		# Proxy settings
		proxy_vip_iface: eth0
		proxy_vip: ${VIP_PROXY}

	EOF
fi

#step 12-17 optional
#step 17
mkdir -p ${INSTALL_DIR}/cluster/images
mv ${BIN_DOWNLOAD_DIR}/${INSTALLER_FILENAME} ${INSTALL_DIR}/cluster/images/

#step 18 optional

#step 19 & 20 - install
cd ${INSTALL_DIR}/cluster && docker run --net=host -t -e LICENSE=accept -v $(pwd):/installer/cluster ${IMAGE_NAME} install
